<h4>Welcome {{ $info['name'] }}</h4>
<p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. In excepturi aliquam voluptas dolore cumque eius mollitia
    non voluptates natus facilis et quibusdam quis repudiandae doloribus quasi quidem, laudantium nostrum unde.</p>
<p>Best Regards,<br> Porto eCommerce</p>
